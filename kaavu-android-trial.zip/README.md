# Kaavu Styles — Android Trial

This is a minimal Android WebView wrapper around the exact Kaavu Styles `v6-4.html` storefront supplied for the trial.

## What is included
- Exact `v6-4.html` copied to `app/src/main/assets/index.html`
- Android WebView with JavaScript and localStorage enabled
- Android back button closes the storefront's open product/cart/menu/flow panel before exiting
- Google Fonts can load over HTTPS
- GitHub Actions workflow builds a debug APK in the cloud

## Build on GitHub
1. Put the project files in the repository.
2. Open **Actions** → **Build Kaavu Styles APK**.
3. Run the workflow if it did not start automatically.
4. Open the completed workflow run and download the `kaavu-styles-debug-apk` artifact.
5. Extract the APK and install it on the Android test phone.

This is a trial wrapper only. No Razorpay credentials, bank credentials, production backend, inventory system, or real payment integration is included.
